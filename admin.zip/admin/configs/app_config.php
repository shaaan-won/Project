<?php
  date_default_timezone_set("Asia/Dhaka");
  $now=date("Y-m-d H:i:s");  
  $base_url="http://localhost/Project_PHP/Rasket_Hotel_Management/admin/";
