<li class="nav-item">
	<a class="nav-link menu-arrow" href="#sidebarPages" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarPages">
		<span class="nav-icon">
			<iconify-icon icon="solar:folder-with-files-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Authentication </span>
	</a>
	<div class="collapse" id="sidebarPages">
		<ul class="nav sub-navbar-nav">
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>user">Users</a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>role">Roles List</a>
			</li>

		</ul>
	</div>
</li> <!-- end pages -->