<li class="nav-item">
	<a class="nav-link menu-arrow" href="#sidebarMaps" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarMaps">
		<span class="nav-icon">
			<iconify-icon icon="solar:streets-map-point-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Hotel Report </span>
	</a>
	<div class="collapse" id="sidebarMaps">
		<ul class="nav sub-navbar-nav">
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>report"> Daily Report </a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>performancereview"> Daily Performance </a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>customerfeedback">Customer Feedback</a>
			</li>

		</ul>
	</div>
</li>