<li class="nav-item">
	<a class="nav-link menu-arrow" href="#sidebarForms" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarForms">
		<span class="nav-icon">
			<iconify-icon icon="solar:checklist-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Rooms Detail </span>
	</a>
	<div class="collapse" id="sidebarForms">
		<ul class="nav sub-navbar-nav">
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>room">Room List</a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>roomtype">Room Types</a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>roomservicerequest">Room Services</a>
			</li>

		</ul>
	</div>
</li>