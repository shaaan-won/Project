<li class="nav-item">
	<a class="nav-link menu-arrow" href="#sidebarIcons" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarIcons">
		<span class="nav-icon">
			<iconify-icon icon="solar:bicycling-broken"></iconify-icon>
		</span>
		<span class="nav-text"> Guest Detail </span>
	</a>
	<div class="collapse" id="sidebarIcons">
		<ul class="nav sub-navbar-nav">
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>customerdetail">Customer List</a>
			</li>
			<li class="sub-nav-item">
				<a class="sub-nav-link" href="<?php echo $base_url ?>idcardtype"> Customer ID type</a>
			</li>

		</ul>
	</div>
</li>