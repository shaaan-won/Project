  </div> <!-- end row-->

</div>

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <script>
                    document.write(new Date().getFullYear())
                </script> &copy; Rasket. Crafted by <iconify-icon icon="solar:hearts-bold-duotone" class="fs-18 align-middle text-danger"></iconify-icon> <a
                    href="https://1.envato.market/techzaa" class="fw-bold footer-text" target="_blank">Techzaa</a>
            </div>
        </div>
    </div>
</footer>
<!-- ========== Footer End ========== -->

</div>
<!-- ==================================================== -->
<!-- End Page Content -->
<!-- ==================================================== -->

</div>
<!-- END Wrapper -->

<!-- Vendor Javascript (Require in all Page) -->
<script src="<?= $base_url ?>assets/js/vendor.js"></script>

<!-- App Javascript (Require in all Page) -->
<script src="<?= $base_url ?>assets/js/app.js"></script>

<!-- Vector Map Js -->
<script src="<?= $base_url ?>assets/vendor/jsvectormap/js/jsvectormap.min.js"></script>
<script src="<?= $base_url ?>assets/vendor/jsvectormap/maps/world-merc.js"></script>
<script src="<?= $base_url ?>assets/vendor/jsvectormap/maps/world.js"></script>

<!-- Dashboard Js -->
<script src="<?= $base_url ?>assets/js/pages/dashboard.js"></script>

<!-- dropdown search -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

</body>


<!-- Mirrored from techzaa.in/rasket/admin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 Nov 2024 03:35:33 GMT -->

</html>