<?php

class HomeController{
    function index(){
        view("dashboard");
    }
}